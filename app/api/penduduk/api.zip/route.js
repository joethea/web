import { supabase } from "@/lib/supabase";

export async function GET(req) {
  try {
    const url = new URL(req.url);
    const search = url.searchParams.get("search") || "";
    const alamatDusun = url.searchParams.get("alamat_dusun") || "";
    const jenisKelamin = url.searchParams.get("jenis_kelamin") || "";
    const umurMin = parseInt(url.searchParams.get("umur_min") || "0", 10);
    const umurMax = parseInt(url.searchParams.get("umur_max") || "200", 10);
    const page = parseInt(url.searchParams.get("page") || "1", 10);
    const limit = parseInt(url.searchParams.get("limit") || "20", 10);
    const offset = (page - 1) * limit;
    const kk = url.searchParams.get("kk") || "";
    const status = url.searchParams.get("status") || "";
    const pekerjaan = url.searchParams.get("pekerjaan") || "";
    const pendidikan = url.searchParams.get("pendidikan") || "";
    const statusKeluarga = url.searchParams.get("status_keluarga") || "";
    const statusYatim = url.searchParams.get("status_yatim") || "";
    const kategoriMiskin = url.searchParams.get("kategori_miskin") || "";
    const kategoriMengaji = url.searchParams.get("kategori_mengaji") || "";
    const tempatMengaji = url.searchParams.get("tempat_mengaji") || "";


// 🔹 Base query
let baseQuery = supabase.from("penduduk").select("*", { count: "exact" });

if (search) {
  baseQuery = baseQuery.or(`nik.ilike.%${search}%,nama.ilike.%${search}%`);
}
if (alamatDusun) {
  baseQuery = baseQuery.ilike("alamat_dusun", `%${alamatDusun}%`);
}
if (jenisKelamin) {
  baseQuery = baseQuery.eq("jenis_kelamin", jenisKelamin);
}
if (kk) {
  baseQuery = baseQuery.eq("kk", String(kk).trim());
}
if (status) {
  baseQuery = baseQuery.eq("status", status);
}
if (pekerjaan) {
  baseQuery = baseQuery.eq("pekerjaan", pekerjaan);
}
if (pendidikan) {
  baseQuery = baseQuery.eq("pendidikan", pendidikan);
}
if (statusKeluarga) {
  baseQuery = baseQuery.eq("status_keluarga", statusKeluarga);
}
if (statusYatim) {
  baseQuery = baseQuery.eq("status_yatim", statusYatim);
}
if (kategoriMiskin) {
  baseQuery = baseQuery.eq("kategori_miskin", kategoriMiskin);
}
if (kategoriMengaji) {
  baseQuery = baseQuery.eq("kategori_mengaji", kategoriMengaji);
}
if (tempatMengaji) {
  baseQuery = baseQuery.eq("tempat_mengaji", tempatMengaji);
}


    if (umurMin || umurMax) {
      const today = new Date();
      const minDate = new Date(today.getFullYear() - umurMax, today.getMonth(), today.getDate());
      const maxDate = new Date(today.getFullYear() - umurMin, today.getMonth(), today.getDate());
      baseQuery = baseQuery.gte("tanggal_lahir", minDate.toISOString().split("T")[0]);
      baseQuery = baseQuery.lte("tanggal_lahir", maxDate.toISOString().split("T")[0]);
    }

    // 🔹 Hitung total hasil filter
    // 🔹 Query dengan count + pagination
const { data, count, error } = await baseQuery
  .range(offset, offset + limit - 1)
  .order("nama", { ascending: true });

if (error) throw new Error(error.message);

return new Response(
  JSON.stringify({
    data: data || [],
    total: count || 0,
    page,
    limit,
  }),
  { headers: { "Content-Type": "application/json" } }
);


    if (dataError) throw new Error(dataError.message);

    return new Response(
      JSON.stringify({
        data: data || [],
        total: count || 0,
        page,
        limit,
      }),
      { headers: { "Content-Type": "application/json" } }
    );
  } catch (e) {
    return new Response(JSON.stringify({ error: e.message }), { status: 500 });
  }
}

export async function POST(req) {
  try {
    const body = await req.json();
    const { nik, nama, tanggal_lahir, alamat_dusun, jenis_kelamin } = body;

    if (!nik || !nama) {
      return new Response(JSON.stringify({ error: "nik & nama required" }), { status: 400 });
    }
    if (!/^\d{16}$/.test(String(nik))) {
      return new Response(
        JSON.stringify({ error: "NIK harus 16 digit angka" }),
        { status: 400 }
      );
    }

    const { error } = await supabase.from("penduduk").insert([
      {
        nik: String(nik),
        nama,
        tanggal_lahir: tanggal_lahir || null,
        alamat_dusun: alamat_dusun || null,
        jenis_kelamin: jenis_kelamin || null,
      },
    ]);

    if (error) throw new Error(error.message);

    return new Response(JSON.stringify({ success: true }), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: e.message }), { status: 500 });
  }
}

export async function PUT(req) {
  try {
    const body = await req.json();
    const { nik, nama, tanggal_lahir, alamat_dusun, jenis_kelamin } = body;

    if (!nik) {
      return new Response(JSON.stringify({ error: "NIK wajib ada untuk update" }), { status: 400 });
    }

    const { error } = await supabase
      .from("penduduk")
      .update({
        nama,
        tanggal_lahir: tanggal_lahir || null,
        alamat_dusun: alamat_dusun || null,
        jenis_kelamin: jenis_kelamin || null,
      })
      .eq("nik", String(nik));

    if (error) throw new Error(error.message);

    return new Response(JSON.stringify({ success: true }), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: e.message }), { status: 500 });
  }
}

export async function DELETE(req) {
  try {
    const url = new URL(req.url);
    const nik = url.searchParams.get("nik");
    if (!nik) {
      return new Response(JSON.stringify({ error: "nik query required" }), { status: 400 });
    }

    const { error } = await supabase
      .from("penduduk")
      .delete()
      .eq("nik", String(nik));

    if (error) throw new Error(error.message);

    return new Response(JSON.stringify({ success: true }), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: e.message }), { status: 500 });
  }
}
